bl_info = {
    "name": "NAD Toolset",
    "author": "NAD",
    "version": (1, 2),
    "blender": (4, 5, 0),
    "location": "View3D > N Panel > Tool",
    "description": "Simple batch renamer",
    "category": "Object",
}

import bpy
import re


class NAD_OT_Rename(bpy.types.Operator):
    bl_idname = "nad.rename_objects"
    bl_label = "Name"

    def execute(self, context):
        base = context.scene.nad_name
        objs = context.selected_objects
        selected_set = set(objs)

        print(f"[NAD] base name: '{base}'")
        print(f"[NAD] selected objects: {[o.name for o in objs]}")

        pattern = re.compile(rf"^SM_{re.escape(base)}_(\d+)$")
        print(f"[NAD] pattern: {pattern.pattern}")

        max_num = 0
        for obj in context.scene.objects:
            if obj in selected_set:
                continue
            m = pattern.match(obj.name)
            if m:
                print(f"[NAD] matched existing: '{obj.name}' -> num {int(m.group(1))}")
                max_num = max(max_num, int(m.group(1)))

        print(f"[NAD] max existing num: {max_num}, starting from: {max_num + 1}")

        for i, obj in enumerate(objs, max_num + 1):
            old_name = obj.name
            obj.name = f"SM_{base}_{i:02d}"
            print(f"[NAD] renamed '{old_name}' -> '{obj.name}'")

        return {'FINISHED'}


class NAD_PT_Toolset(bpy.types.Panel):
    bl_label = "NAD Toolset"
    bl_idname = "NAD_PT_toolset"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "nad_name")
        layout.operator("nad.rename_objects")


classes = (
    NAD_OT_Rename,
    NAD_PT_Toolset,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.nad_name = bpy.props.StringProperty(name="Name")

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.nad_name


if __name__ == "__main__":
    register()
